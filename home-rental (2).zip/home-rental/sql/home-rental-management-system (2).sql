-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2020 at 04:00 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `home-rental-management-system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admininfo`
--

CREATE TABLE `admininfo` (
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admininfo`
--

INSERT INTO `admininfo` (`name`, `username`, `password`, `email`, `phone`) VALUES
('ashiq', 'admin', 'admin', 'email', 21548);

-- --------------------------------------------------------

--
-- Table structure for table `customerinfo`
--

CREATE TABLE `customerinfo` (
  `fname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fathersName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nid` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportNo` int(10) NOT NULL,
  `status` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customerinfo`
--

INSERT INTO `customerinfo` (`fname`, `lname`, `username`, `password`, `email`, `phone`, `type`, `fathersName`, `nid`, `reportNo`, `status`) VALUES
('Ashiqul Hoque', 'chowdhury', 'what', 'what', 'ehat', '0356', 'available', 'adhgja', 'sdfds', 0, 'unblock'),
('MURAD', 'ALAM', 'ma', '12345678', 'ma@gmail.com', '01705719021', 'available', 'NA', '12345678910123456', 0, 'unblock');

-- --------------------------------------------------------

--
-- Table structure for table `houseinfo`
--

CREATE TABLE `houseinfo` (
  `houseid` int(10) NOT NULL,
  `housename` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(10) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `prize` int(10) NOT NULL,
  `review` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ownersname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customername` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `houseinfo`
--

INSERT INTO `houseinfo` (`houseid`, `housename`, `division`, `area`, `address`, `size`, `description`, `prize`, `review`, `status`, `ownersname`, `customername`) VALUES
(1, 'something', 'Chittagong', 'Chawkbazar', 'another', 20000, 'someantoher', 36000, 'no', 'available', 'sa', NULL),
(10, 'asas', 'Chittagong', 'Agrabad', 'asas', 0, 'asas', 0, 'no', 'available', 'sa', NULL),
(11, 'batman', 'Chittagong', 'GEC', 'bathouse', 1200, '4 bed', 25000, 'no', 'available', 'sa', NULL),
(12, 'batman', 'Chittagong', 'GEC', 'bathouse', 1200, '4 bed', 25000, 'no', 'available', 'sa', NULL),
(13, 'boshor tower', 'Dhaka', 'Bashundhara', 'chandgaon', 2550, '5 bed', 26000, 'no', 'available', 'sa', NULL),
(14, 'df', 'Chittagong', 'Chawkbazar', 'ds', 2100, '5', 21000, 'no', 'available', 'sa', NULL),
(15, 'qwe', 'Chittagong', 'GEC', 'qwe', 25000, '4 bed', 25000, 'no', 'available', 'sa', NULL),
(16, 'mdc', 'Dhaka', 'Bashundhara', 'No', 1422, '3bed', 14555, 'no', 'available', 'sa', NULL),
(17, 'mdc', 'Dhaka', 'Bashundhara', 'No', 1422, '3bed', 14555, 'no', 'available', 'sa', NULL),
(19, 'asd', 'Chittagong', 'Agrabad', 'asd', 2500, 'aDS', 30000, 'no', 'available', 'sa', NULL),
(20, 'mdc', 'Chittagong', 'Anderkilla', '45', 1200, '3bed', 25000, 'no', 'available', 'sa', NULL),
(21, 'asd', 'Chittagong', 'GEC', 'asd', 1200, 'asd', 12000, 'no', 'available', 'sa', NULL),
(22, 'mdc', 'Dhaka', 'Banani', 'asd', 1700, 'asd', 17000, 'no', 'available', 'sa', NULL),
(23, 'asasfd', 'Dhaka', 'Mirpur', 'asdsad', 2900, 'asdasd', 29000, 'no', 'available', 'sa', NULL),
(24, 'next', 'Dhaka', 'Bashundhara', 'xnet', 30003, 'sdsdsd', 2000, 'no', 'available', 'sa', NULL),
(25, 'first', 'Chittagong', 'Agrabad', 'first', 30003, 'fisrt', 2000, 'no', 'available', 'sa', NULL),
(26, 'second', 'Dhaka', 'Nikunja', 'secomd', 30003, 'fisrt', 2000, 'no', 'available', 'sa', NULL),
(30, 'new', 'Dhaka', 'Uttara', '29', 1500, '3 bed', 25000, 'no', 'rented', 'sa', 'what'),
(49, 'hell\'s kitchen', 'Dhaka', 'Uttara', '145', 2200, '4 bed', 25000, 'no', 'rented', 'fdf', 'what'),
(50, 'first', 'Dhaka', 'Banani', '1554', 2500, '5 bed', 35000, 'no', 'available', 'sa', NULL),
(52, 'Tower', 'Chittagong', 'Anderkilla', '135', 1100, '2 bed', 25000, 'no', 'available', 'sa\r\n', NULL),
(55, 'maati', 'Chittagong', 'Chandgaon', '1223', 2400, '5 bed', 25000, 'no', 'available', 'sa', NULL),
(56, 'mdc', 'Chittagong', 'Chandgaon', '2wdqwd', 1300, '3bed', 25000, 'no', 'available', 'sa', NULL),
(58, 'dd', 'Dhaka', 'Banani', '1222edq', 1300, '3bed', 20000, 'no', 'available', 'sa', NULL),
(59, 'FWDAF', 'Chittagong', 'Chawkbazar', 'hgc', 20000, 'fcfg', 1500, 'no', 'available', 'sa', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `houseownerinfo`
--

CREATE TABLE `houseownerinfo` (
  `fname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fathersName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nid` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reportNo` int(10) NOT NULL,
  `status` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `houseownerinfo`
--

INSERT INTO `houseownerinfo` (`fname`, `lname`, `username`, `password`, `email`, `phone`, `type`, `fathersName`, `nid`, `reportNo`, `status`) VALUES
('dfdf', 'df', 'fdf', 'dff', 'df', '01836252698', 'available', 'sa', 'sa', 0, 'unblock'),
('as', 'sa', 'sa', '1234', 'sa', '01836252698', 'available', 'sa', 'sa', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `incustomerinfo`
--

CREATE TABLE `incustomerinfo` (
  `customername` varchar(256) NOT NULL,
  `houseownername` varchar(256) NOT NULL,
  `houseid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `incustomerinfo`
--

INSERT INTO `incustomerinfo` (`customername`, `houseownername`, `houseid`) VALUES
('jamal', 'as', 31),
('ma', 'fdf', 22),
('task', 'sa', 30);

-- --------------------------------------------------------

--
-- Table structure for table `managerinfo`
--

CREATE TABLE `managerinfo` (
  `fname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(20) NOT NULL,
  `division` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fathersName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nid` int(20) NOT NULL,
  `status` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `managerinfo`
--

INSERT INTO `managerinfo` (`fname`, `lname`, `username`, `password`, `email`, `phone`, `division`, `area`, `fathersName`, `nid`, `status`) VALUES
('Ashiqul Hoque', 'chowdhury', 'as', 'new', 'ashiqulhoque45@gmail.com', 1670464084, NULL, '', 'something', 16704, 'block'),
('Ashiqul Hoque', 'chowdhury', 'ashiq4321', 'ashiq4321', 'ashiqulhoque45@gmail.com', 1823828500, 'Dhaka', 'bashundhara', 'shafiqul hoque chowdhury', 1670464084, '');

-- --------------------------------------------------------

--
-- Table structure for table `rentedhouseinfo`
--

CREATE TABLE `rentedhouseinfo` (
  `houseid` int(11) NOT NULL,
  `customername` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `houseinfo`
--
ALTER TABLE `houseinfo`
  ADD PRIMARY KEY (`houseid`);

--
-- Indexes for table `incustomerinfo`
--
ALTER TABLE `incustomerinfo`
  ADD PRIMARY KEY (`houseownername`);

--
-- Indexes for table `rentedhouseinfo`
--
ALTER TABLE `rentedhouseinfo`
  ADD PRIMARY KEY (`houseid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
