var express = require('express');
var router = express.Router();
var houseProviderModel = require.main.require('./models/houseprovider-model');


router.get('*', function (req, res, next) {
	if (req.cookies['uname'] == null) {
		res.redirect('/login');
	} else {
		next();
	}
});
router.get('/', function (req, res) {
	houseProviderModel.getByUname(req.cookies['uname'], function (result) {
		res.render('houseprovider/index', {
			user: result
		});
	});
});

router.post('/newAdvertise', function (req, res) {
	
	
	var house = {
		    hid: "13",
			hname: req.body.hname,
			Area: req.body.Area,
			output: req.body.output,
			faddress: req.body.faddress,
			addescription: req.body.addescription,
			size: req.body.size,
			price: req.body.price,
	}
			
	houseProviderModel.insert(house, function (result) {
		res.render('houseprovider/viewOwn', {
			user: result
		});
	});

});
router.get('/newAdvertise', function (req, res) {
	houseProviderModel.getByUname(req.cookies['uname'], function (result) {
		res.render('houseprovider/newAdvertise', {
			user: result
		});
	});

});

router.get('/profile', function (req, res) {
	houseProviderModel.getByUname(req.cookies['uname'], function (result) {
		res.render('houseprovider/profile', {
			user: result
		});
	});

});

router.get('/newAdvertise', function (req, res) {
	houseProviderModel.insert(req.cookies['uname'], function (result) {
		res.render('houseprovider/viewOwn', {
			user: result
		});
	});

});
router.post('/profile', function (req, res) {
	if (req.body.password == req.body.cpassword) {
		var user = {
			fname: req.body.fname,
			lname: req.body.lname,
			username: req.body.uname,
			fathersName: req.body.fathersName,
			email: req.body.email,
			phone: req.body.phone,
			password: req.body.password,
			area: req.body.area
		};

		houseProviderModel.updateProfile(user, function (status) {
			if (status) {
				res.redirect('/houseprovider');
			} else {
				res.redirect('/houseprovider/profile');
			}
		});
	} else {
		res.send('password mismatch');
	}
});


module.exports = router;
